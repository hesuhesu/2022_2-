#pragma once
#include "pmp/surface_mesh.h"
class DrawComponent
{
public:
    void Init();
    void InitLoadFile();
    void InitMyMesh();
    void Draw();

    pmp::SurfaceMesh mesh;
};

