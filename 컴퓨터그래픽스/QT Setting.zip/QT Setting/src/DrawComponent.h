#pragma once

class DrawComponent
{
public:
    void Init();

    void Draw();
};

