#include "DrawComponent.h"
#include "gl/freeglut.h"

void DrawComponent::Init()
{

}

void DrawComponent::Draw()
{

}